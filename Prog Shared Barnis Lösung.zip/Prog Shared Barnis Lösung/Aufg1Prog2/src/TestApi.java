
public class TestApi {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Share audi =new Share("audi", 5);
		Share facebook =new Share("facebook", 11); //Create two new Shares
		
		
		ShareItem packageaudi=new ShareItem(audi,33);
		ShareItem packagefacebook=new ShareItem(facebook, 12); //Create Share Packages
		
		
		ShareDeposit depositBernd=new ShareDeposit("BerndsDeposit"); //Create a new Player Deposit
		CashAcount cashAcountBernd=new CashAcount(10000,"BerndsCashAcount"); //Create a new Player CashAcount
		
		depositBernd.buyShares(packageaudi);
		depositBernd.buyShares(packagefacebook); //Buy the Share Packages and move them into Deposit
		
		System.out.println(depositBernd.toString()); //Print Info
		
		depositBernd.sellShares(packagefacebook); //Sell FB Shares and check result
		System.out.println("Nach FB Verkauf:");
		System.out.println(depositBernd.toString());	
		
		System.out.println("Nach audi Verkauf:"); //Sell audi Shares and check result
		depositBernd.sellShares(packageaudi);
		System.out.println(depositBernd.toString());
		
		
		System.out.println("____________________________________________");
		System.out.println(cashAcountBernd.toString()); //Test String CashAcount
		cashAcountBernd.raise(120);
		System.out.println(cashAcountBernd.toString()); //Test raise CashAcount
		cashAcountBernd.degrade(500);
		System.out.println(cashAcountBernd.toString()); //Test degrade CashAcount
	}

}
