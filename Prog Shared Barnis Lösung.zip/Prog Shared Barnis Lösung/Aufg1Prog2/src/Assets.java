public class Assets {

	protected String name;
	protected long value;
	
	protected Assets(String name, long value)
	{
		this.name = name;
		this.value = value;
	}
	
	public String toString() {
		throw new UnsupportedOperationException();
	}

	/**
	 * This Method will compare two Assets, got to be implemented first
	 */
	public void compare() {
		throw new UnsupportedOperationException();
	}

}