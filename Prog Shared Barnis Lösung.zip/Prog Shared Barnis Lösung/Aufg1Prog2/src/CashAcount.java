public class CashAcount extends Assets {

	

	/**
	 * Constructor
	 * @param startValue the value that the CashAcount has at the beginning
	 * @param name the name of the CashAcount
	 */
	public CashAcount(long startValue,String name){
		super(name, startValue);
	}
	

	/**
	 * This Method gives the functionality to raise the value of the CashAcount
	 * @param value the value the CashAcount shall be increased
	 */
	public void raise(long value) {
		if (value<0){
			System.out.println ("your value is beneth 0 Euros, wanted to degrade??");
		}
		this.value+=value;
	}

	/**
	 * This Method degrade the value of the CashAcount
	 * @param value the value the CashAcount shall be degraded
	 */
	public void degrade(long value) {
		if (value<0){
			System.out.println ("You only can degrade with a positive value");
		}
//		if (value>getValue()){ //what happens when out of money?! at the moment its ok...
//			
//		}
		this.value-=value;
	}
	
	
	/**
	 * 
	 * @return the current value
	 */
	public long getValue(){
		return this.value;
	}
	
	/**
	 * 
	 * @return the name of the CashAcount
	 */
	public String getName(){
		return this.name;
	}
	
	@Override
	public String toString() {
		String s=("Your CashAcount '" + getName() + "' has the current value: " + getValue()) + " Euros";
		return s;
	}

}