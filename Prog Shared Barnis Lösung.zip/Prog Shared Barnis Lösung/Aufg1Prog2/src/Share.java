public class Share {

	public final String name;
	private long course;
	
	/**
	 * Constructor
	 * @param name  The name of the Share
	 * @param course  The current course of the Share
	 */
	public Share (String name, long course){
		this.name=name;
		setCourse(course);
	}

	/**
	 * Sets the course
	 * @param course  The current course or new course
	 */
	public void setCourse(long course) {
		this.course=course;
	}
	
	/**
	 * This method returns the Course
	 * @return current course
	 */
	public long getCourse() {
		return this.course;
	}

	/**
	 * This method returns the Shares name
	 * @return name
	 */
	public String getName() {
		return this.name;
	}

	@Override
	public String toString() {
		String s = "'" + this.name + "' has the course: " +this.course + " cents \r\n";
		return s;
	}


	
}