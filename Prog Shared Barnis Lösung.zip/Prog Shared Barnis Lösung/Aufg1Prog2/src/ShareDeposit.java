public class ShareDeposit extends Assets {

	private ShareItem[] shareItems=new ShareItem[0]; //Initialize array with one space
		
	/**
	 * Constructor
	 * @param name the name of the Deposit
	 */
	public ShareDeposit(String name){
		super(name, 0);  //0 ShareItems at the beginning!
	}
	/**
	 * This Method gives functionality to buy a new ShareItem
	 * @param shareItem The Share Item to buy
	 */
	public void buyShares(ShareItem shareItem) {  //must be linked with CashAcount later
		ShareItem[] array=new ShareItem[shareItems.length+1];  //add one array space
		for (int i=0;i<shareItems.length;i++){ //write smaller array on larger one
			array[i]=shareItems[i];
		}
		array[array.length-1]=shareItem; //copy the new Element on last space in Array
		this.shareItems=array;
	}
	/**
	 * This Method gives the functionality to sell ShareItems
	 * @param shareItem The Share Item to sell
	 */
	public void sellShares(ShareItem shareItem) { //must be linked with CashAcount later
		int i=0;  // points on space in Array where the ShareItem is, that should be removed
		for ( i=0;i<this.shareItems.length;i++){  
			if (this.shareItems[i].equals(shareItem))  //search the Element in the Deposit Array, if there break!
			break;
			
		}
		if (i==this.shareItems.length)  //run to end of Array? so its not there
			System.out.println("Your selected ShareItem isn't part of your Deposit!!");
		else
		{
			ShareItem[] array=new ShareItem[shareItems.length-1];  //initialize new Array one space smaller
			int counter=0;  
			for (int g=0;g<shareItems.length;g++){  
				if (g==i){}  //dont copy the item that lays on the variable i because its the one that have to be removed!
			else{
				array[counter]=shareItems[g]; //copy all other items
				counter++;  //makes sure not to run out of array
				}
			}
			this.shareItems=array;  //initialize new array
		}
	}
	
	/**
	 * This Method gives the functionality to sell the whole ShareItems
	 * 
	 */
	public void sellWholeShares(){  //must be linked with CashAcount later
		ShareItem [] array=new ShareItem[0];
		this.shareItems=array; //just replace all Spaces in Array....
	}
	
	
	@ Override
	public String toString() {
	StringBuffer parts=new StringBuffer();
	String s=("The deposit " +this.name + " contains " + this.shareItems.length + " packages: \r\n" );
	String line=("________________________________________________________________\n\r");	
	if (shareItems.length>0){
		for (int i=0;i<this.shareItems.length;i++){
			String g=shareItems[i].toString();
			parts.append(g+line);
		}
	}
	else parts.append("no Shares!!!");
	return s+parts;
	}
	
	
	
	
}