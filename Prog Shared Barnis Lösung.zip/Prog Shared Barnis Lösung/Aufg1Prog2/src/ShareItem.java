public class ShareItem extends Assets {

	//private long totalAssets;
	private int units;
	private final Share Share;
	

	/**
	 * Constructor
	 * @param Shares  The Shares that got to be packed in a package
	 * @param units  The number of units
	 */
	public ShareItem(Share Shares, int units) {
		super(Shares.getName(), units*Shares.getCourse());
		this.Share=Shares;
		//this.name=Shares.getName()+" ShareItem";
		this.units=units;
		//this.totalAssets=units*Shares.getCourse();	//sets the total value of the package		
	}
	/**
	 * This Method refreshes the totalAsset
	 */
	public void refreshTotalAssets (){
		this.value=this.units*this.Share.getCourse();
	}

	/**
	 * This Method adds units to the package and after that refreshes the totalAssets amount
	 * @param units The amount of units, the package shall be increased
	 */
	public void addUnits(int units) { //add units refresh AssetValue
		if (units>0){
		this.units+=units;
		refreshTotalAssets();
		}
		else{}
	}
	/**
	 * This Method removes units from the package and after that refreshes value of totalAssets
	 * @param units The amount of units, the package shall be decreased
	 *
	 */
	public void removeUnits(int units){ 
		if (units>this.units){ //Make sure the number is correct
			System.out.println("You dont have that much units");
		}
		else if (units<0){
			units=units*-1; //convert into positive number
			this.units-=units;
		}
		else {
			this.units-=units;
		}
		refreshTotalAssets();  //refresh the new total Asset amount
	}
	
	/**
	 * 
	 * @return the totalAssets amount of this ShareItem
	 */
	public long getTotalAssets(){
		return this.value;
	}
	
	/**
	 * 
	 * @return the units of the ShareItem
	 */
	public int getUnits(){
		return this.units;
	}
	/**
	 * 
	 * @return the name of the ShareItem
	 */
	public String getName(){
		return this.name;
	}
	/**
	 * 
	 * @return the Share that is held in the ShareItem
	 */
	public Share getShare(){
		return this.Share;
	}
	
	@Override
	public String toString() {
		String s="The total Amount of your package '" + this.name + "' contains " + this.units + " units of '" + this.Share.getName() + "'\r\n";
		return s + this.Share.toString();
	}

}